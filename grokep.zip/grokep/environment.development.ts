export const environment = {
    production: false,
    Base_Api_Url:"http://localhost:3000",
    buses_url:"/buses",
    assignments_url:"/assignments",
    students_url:"/students"
}
