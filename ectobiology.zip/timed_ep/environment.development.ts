export const environment = {
    production: false,
    Base_Api_Url:"http://localhost:3000/api/v1",
    events_url:"/events",
    attendees_url:"/attendees"
}
