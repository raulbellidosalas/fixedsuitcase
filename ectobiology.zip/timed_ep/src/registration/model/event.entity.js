export class event{
    constructor({
                    id=0,
                    name='',
                    description='',
                    scheduledAt='',
                }){

        this.id=id;
        this.name=name;
        this.description=description;
        this.scheduledAt=scheduledAt;

    }
}